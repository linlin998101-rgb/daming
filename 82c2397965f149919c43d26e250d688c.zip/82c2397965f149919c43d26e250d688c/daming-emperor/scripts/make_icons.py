#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
《大明皇帝》APP 图标生成脚本
输入：用户上传的 88x108 竖版照片（attachment）
输出：
  - mipmap-{mdpi,hdpi,xhdpi,xxhdpi,xxxhdpi}/ic_launcher.png + ic_launcher_round.png（传统图标）
  - drawable-nodpi/ic_launcher_foreground.png（自适应图标前景，居中安全区）
  - mipmap-anydpi-v26/ic_launcher.xml + ic_launcher_round.xml（自适应图标）
  - values/ic_launcher_background.xml（背景色，取原图边缘均值色）
处理原则：保持原图内容不变，不添加任何特效/滤镜，仅做居中、缩放与背景填充。
"""
import os
from PIL import Image, ImageStat

SRC = "/home/user/.doubao/agent_mode/workspace/.sessions/174054944767234/attachments/attachment_1789476358_0"
RES_DIR = "/home/user/Doubao/chats/174054944767234/daming-emperor/android/app/src/main/res"

BASE = 1080  # 底图边长
SIZES = {"mdpi": 48, "hdpi": 72, "xhdpi": 96, "xxhdpi": 144, "xxxhdpi": 192}
FG_RATIO = 0.72  # 自适应前景内原图占比（保证头像位于安全区）


def edge_color(img: Image.Image) -> tuple:
    w, h = img.size
    k = 24
    patches = [
        img.crop((0, 0, k, k)),
        img.crop((w - k, 0, w, k)),
        img.crop((0, h - k, k, h)),
        img.crop((w - k, h - k, w, h)),
    ]
    stats = [ImageStat.Stat(p) for p in patches]
    r = sum(s.mean[0] for s in stats) / len(stats)
    g = sum(s.mean[1] for s in stats) / len(stats)
    b = sum(s.mean[2] for s in stats) / len(stats)
    return (int(r), int(g), int(b))


def make_square_base(img: Image.Image, bg: tuple) -> Image.Image:
    """等比缩放到宽=BASE，上下补背景色，得到 BASE x BASE 正方形底图"""
    img = img.convert("RGB")
    w, h = img.size
    scale = BASE / w
    nw, nh = BASE, int(h * scale)
    img = img.resize((nw, nh), Image.LANCZOS)
    canvas = Image.new("RGB", (BASE, BASE), bg)
    canvas.paste(img, (0, (BASE - nh) // 2))
    return canvas


def main():
    img = Image.open(SRC)
    bg = edge_color(img.convert("RGB"))
    square = make_square_base(img, bg)

    # 1) 传统 mipmap 图标
    for density, size in SIZES.items():
        out_dir = os.path.join(RES_DIR, f"mipmap-{density}")
        os.makedirs(out_dir, exist_ok=True)
        icon = square.resize((size, size), Image.LANCZOS)
        icon.save(os.path.join(out_dir, "ic_launcher.png"), "PNG")
        icon.save(os.path.join(out_dir, "ic_launcher_round.png"), "PNG")

    # 2) 自适应图标前景（透明底，原图占 72% 居中）
    fg_dir = os.path.join(RES_DIR, "drawable-nodpi")
    os.makedirs(fg_dir, exist_ok=True)
    fg = Image.new("RGBA", (BASE, BASE), (0, 0, 0, 0))
    inner = int(BASE * FG_RATIO)
    scaled = square.resize((inner, inner), Image.LANCZOS)
    fg.paste(scaled, ((BASE - inner) // 2, (BASE - inner) // 2))
    fg.save(os.path.join(fg_dir, "ic_launcher_foreground.png"), "PNG")

    # 3) 自适应图标 XML（API 26+）
    anydpi = os.path.join(RES_DIR, "mipmap-anydpi-v26")
    os.makedirs(anydpi, exist_ok=True)
    adaptive = '''<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@color/ic_launcher_background" />
    <foreground android:drawable="@drawable/ic_launcher_foreground" />
    <monochrome android:drawable="@drawable/ic_launcher_foreground" />
</adaptive-icon>
'''
    for name in ("ic_launcher.xml", "ic_launcher_round.xml"):
        with open(os.path.join(anydpi, name), "w", encoding="utf-8") as f:
            f.write(adaptive)

    # 4) 背景色资源
    hex_color = "#{:02X}{:02X}{:02X}".format(*bg)
    values_dir = os.path.join(RES_DIR, "values")
    os.makedirs(values_dir, exist_ok=True)
    with open(os.path.join(values_dir, "ic_launcher_background.xml"), "w", encoding="utf-8") as f:
        f.write(f'''<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="ic_launcher_background">{hex_color}</color>
</resources>
''')

    print("OK bg=%s square=%s" % (hex_color, square.size))


if __name__ == "__main__":
    main()
