#!/usr/bin/env bash
# 《大明皇帝》dpt-shell 加固脚本（默认/轻量模式）
# 用法：
#   export JAVA_HOME=<JDK17路径>
#   export ANDROID_HOME=<Android SDK路径>
#   bash scripts/harden-apk.sh
#
# 流程：app-release.apk -> dpt 加固 -> apksigner 用 debug keystore 重签名 -> app-protected.apk
# 注意：如果加固后出现启动崩溃/兼容性问题，回退使用未加固的 app-release.apk。
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BUILD="$ROOT/build"
DPT_DIR="$ROOT/.dpt"
DPT_JAR="$DPT_DIR/dpt.jar"
DPT_VERSION="${DPT_VERSION:-1.2.1}"

ANDROID_HOME="${ANDROID_HOME:?请先设置 ANDROID_HOME}"
JAVA_HOME="${JAVA_HOME:-}"
if [ -n "$JAVA_HOME" ]; then
  export PATH="$JAVA_HOME/bin:$PATH"
fi

INPUT="$BUILD/app-release.apk"
OUT_UNSIGNED="$BUILD/app-protected-unsigned.apk"
OUT_SIGNED="$BUILD/app-protected.apk"
KS="$HOME/.android/debug.keystore"

[ -f "$INPUT" ] || { echo "错误：找不到 $INPUT，请先运行 scripts/build-apk.sh" >&2; exit 1; }

# 1) 获取 dpt-shell（GitHub 不可达时手动下载后放到 $DPT_DIR）
if [ ! -f "$DPT_JAR" ]; then
  echo "==> 下载 dpt-shell v$DPT_VERSION"
  mkdir -p "$DPT_DIR"
  curl -L --max-time 300 -o "$DPT_DIR/dpt.zip" \
    "https://github.com/luoyesiqiu/dpt-shell/releases/download/v${DPT_VERSION}/dpt-${DPT_VERSION}.zip"
  unzip -o "$DPT_DIR/dpt.zip" -d "$DPT_DIR"
fi

# 2) 加固（默认模式：DEX 加密 + 基础反调试）
echo "==> 加固（默认/轻量模式）"
java -jar "$DPT_JAR" -a "$INPUT" -o "$OUT_UNSIGNED"

# 3) debug keystore 重签名
APKSIGNER="$(find "$ANDROID_HOME/build-tools" -name apksigner | sort -V | tail -1)"
echo "==> 使用 $APKSIGNER 签名"
if [ ! -f "$KS" ]; then
  # debug keystore 不存在时由 keytool 生成（与 AGP 默认一致）
  keytool -genkeypair -v -keystore "$KS" -storepass android -alias androiddebugkey \
    -keypass android -keyalg RSA -keysize 2048 -validity 10000 \
    -dname "CN=Android Debug,O=Android,C=US"
fi
"$APKSIGNER" sign \
  --ks "$KS" --ks-pass pass:android --key-pass pass:android \
  --ks-key-alias androiddebugkey \
  --out "$OUT_SIGNED" "$OUT_UNSIGNED"

echo "==> 完成：build/app-protected.apk"
