#!/usr/bin/env bash
# 《大明皇帝》一键构建脚本：构建 debug 签名的 release APK
# 用法：
#   export JAVA_HOME=<JDK17路径>
#   export ANDROID_HOME=<Android SDK路径>
#   bash scripts/build-apk.sh
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT/android"

echo "==> JAVA_HOME=${JAVA_HOME:?请先设置 JAVA_HOME（JDK 17）}"
echo "==> ANDROID_HOME=${ANDROID_HOME:?请先设置 ANDROID_HOME（Android SDK）}"

if [ ! -x "$JAVA_HOME/bin/java" ]; then
  echo "错误：JAVA_HOME 下找不到 java" >&2
  exit 1
fi

mkdir -p "$ROOT/build"

if [ -x ./gradlew ]; then
  GRADLE_CMD="./gradlew"
elif command -v gradle >/dev/null 2>&1; then
  GRADLE_CMD="gradle"
else
  echo "错误：未找到 gradlew 或 gradle" >&2
  exit 1
fi

"$GRADLE_CMD" :app:assembleRelease --no-daemon

cp app/build/outputs/apk/release/app-release.apk "$ROOT/build/app-release.apk"
echo "==> 完成：build/app-release.apk"
