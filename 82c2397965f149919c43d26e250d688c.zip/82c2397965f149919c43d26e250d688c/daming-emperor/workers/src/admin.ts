/**
 * 管理模块（全部要求 role === 'admin'）：
 *   GET   /api/admin/users?page=1&pageSize=50
 *   PATCH /api/admin/users/:id/balance
 *   POST  /api/admin/announcements
 */

import type { Env, User } from './types';
import { ApiError, BILL_TYPES } from './types';
import { json, readBody, nowSeconds, paginate, asString, isSafeInteger } from './db';
import { requireAdmin } from './auth';

/** GET /api/admin/users 分页用户列表，按创建时间倒序 */
export async function adminUsers(env: Env, req: Request, url: URL): Promise<Response> {
  await requireAdmin(env, req);
  const { page, pageSize, offset } = paginate(url, 50);

  const totalRow = await env.DB.prepare('SELECT COUNT(*) AS c FROM users').first<{ c: number }>();
  const total = totalRow?.c ?? 0;

  const { results } = await env.DB.prepare(
    `SELECT id, nickname, role, balance, created_at
     FROM users
     ORDER BY created_at DESC, id DESC
     LIMIT ? OFFSET ?`,
  )
    .bind(pageSize, offset)
    .all<{ id: string; nickname: string; role: string; balance: number; created_at: number }>();

  const list = results.map((r) => ({
    id: r.id,
    nickname: r.nickname,
    role: r.role,
    balance: r.balance,
    createdAt: r.created_at,
  }));

  return json({ list, page, pageSize, total });
}

/**
 * PATCH /api/admin/users/:id/balance
 * 请求：{ "mode": "set" | "add", "amount": 100, "description": "..." }
 * 事务：更新 users.balance + 插入 bills + 插入 admin_logs（D1 batch 原子执行）
 */
export async function adminSetBalance(
  env: Env,
  req: Request,
  url: URL,
): Promise<Response> {
  const { user: admin } = await requireAdmin(env, req);

  const segments = url.pathname.split('/').filter(Boolean); // ['api','admin','users','<id>','balance']
  const targetId = segments.length === 5 ? decodeURIComponent(segments[3]) : '';
  if (!targetId) throw new ApiError(400, '缺少用户 ID');

  const body = await readBody(req);
  const mode = asString(body.mode);
  if (mode !== 'set' && mode !== 'add') throw new ApiError(400, 'mode 必须为 set 或 add');
  if (!isSafeInteger(body.amount)) throw new ApiError(400, 'amount 必须为整数');
  const description = asString(body.description)?.trim() ?? '';
  if (!description) throw new ApiError(400, '修改余额时必须填写说明');

  const targetRow = await env.DB.prepare('SELECT * FROM users WHERE id = ?')
    .bind(targetId)
    .first();
  if (!targetRow) throw new ApiError(404, '用户不存在');
  const target = targetRow as unknown as User;

  const oldBalance = target.balance;
  const amount = body.amount;
  const newBalance = mode === 'set' ? amount : oldBalance + amount;
  if (!Number.isSafeInteger(newBalance)) throw new ApiError(400, '余额超出整数范围');

  const delta = newBalance - oldBalance;
  const billType =
    mode === 'set' ? BILL_TYPES.ADMIN_SET : delta >= 0 ? BILL_TYPES.ADMIN_ADD : BILL_TYPES.ADMIN_SUBTRACT;
  const now = nowSeconds();

  // D1 batch：三条语句同一事务，任一步失败整体回滚
  await env.DB.batch([
    env.DB.prepare('UPDATE users SET balance = ?, updated_at = ? WHERE id = ?').bind(
      newBalance,
      now,
      targetId,
    ),
    env.DB.prepare(
      'INSERT INTO bills (id, user_id, type, amount, balance_after, description, created_by, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
    ).bind(
      crypto.randomUUID(),
      targetId,
      billType,
      delta,
      newBalance,
      description,
      admin.id,
      now,
    ),
    env.DB.prepare(
      'INSERT INTO admin_logs (id, admin_id, target_user_id, action, before_value, after_value, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)',
    ).bind(
      crypto.randomUUID(),
      admin.id,
      targetId,
      mode === 'set' ? 'set_balance' : 'add_balance',
      String(oldBalance),
      String(newBalance),
      now,
    ),
  ]);

  return json({
    user: { id: target.id, nickname: target.nickname, role: target.role, balance: newBalance },
  });
}

/** POST /api/admin/announcements 发布全局公告（active=1） */
export async function adminAnnouncement(env: Env, req: Request): Promise<Response> {
  const { user: admin } = await requireAdmin(env, req);
  const body = await readBody(req);
  const title = asString(body.title)?.trim() ?? '';
  const content = asString(body.content)?.trim() ?? '';
  if (!title || !content) throw new ApiError(400, '标题和内容不能为空');

  const id = crypto.randomUUID();
  const now = nowSeconds();
  await env.DB.prepare(
    'INSERT INTO announcements (id, title, content, active, created_by, created_at) VALUES (?, ?, ?, 1, ?, ?)',
  )
    .bind(id, title, content, admin.id, now)
    .run();

  return json(
    { id, title, content, active: 1, createdBy: admin.id, createdAt: now },
    201,
  );
}
