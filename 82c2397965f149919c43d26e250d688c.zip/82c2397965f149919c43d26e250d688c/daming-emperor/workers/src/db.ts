/**
 * 通用请求/响应/参数工具
 */

import { ApiError } from './types';

/** JSON 响应 */
export function json(data: unknown, status = 200): Response {
  return new Response(JSON.stringify(data), {
    status,
    headers: { 'Content-Type': 'application/json; charset=utf-8' },
  });
}

/** 统一错误响应：{ "error": { "code": <http状态码>, "message": "..." } } */
export function fail(code: number, message: string): Response {
  return json({ error: { code, message } }, code);
}

/** 解析请求体 JSON（非法 JSON -> 400） */
export async function readBody(req: Request): Promise<Record<string, unknown>> {
  try {
    const raw = await req.text();
    if (!raw) return {};
    const parsed: unknown = JSON.parse(raw);
    if (parsed === null || typeof parsed !== 'object' || Array.isArray(parsed)) {
      throw new Error('body must be object');
    }
    return parsed as Record<string, unknown>;
  } catch {
    throw new ApiError(400, '请求体不是合法 JSON 对象');
  }
}

/** 当前 Unix 秒 */
export function nowSeconds(): number {
  return Math.floor(Date.now() / 1000);
}

/** 解析分页参数，带默认值与上限 */
export function paginate(
  url: URL,
  defaultPageSize = 20,
): { page: number; pageSize: number; offset: number } {
  let page = parseInt(url.searchParams.get('page') ?? '1', 10);
  let pageSize = parseInt(url.searchParams.get('pageSize') ?? String(defaultPageSize), 10);
  if (!Number.isInteger(page) || page < 1) page = 1;
  if (!Number.isInteger(pageSize) || pageSize < 1) pageSize = defaultPageSize;
  if (pageSize > 100) pageSize = 100;
  return { page, pageSize, offset: (page - 1) * pageSize };
}

export function isNonEmptyString(v: unknown): v is string {
  return typeof v === 'string' && v.trim().length > 0;
}

export function asString(v: unknown): string | null {
  return typeof v === 'string' ? v : null;
}

export function isSafeInteger(v: unknown): v is number {
  return typeof v === 'number' && Number.isSafeInteger(v);
}

/** 昵称长度（按 Unicode 码点计，中文每个字算 1 个） */
export function nicknameLength(s: string): number {
  return Array.from(s.trim()).length;
}

/** 公开的用户信息（不泄露任何敏感字段） */
export function publicUser(u: { id: string; nickname: string; role: string; balance: number }) {
  return { id: u.id, nickname: u.nickname, role: u.role, balance: u.balance };
}
