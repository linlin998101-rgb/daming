/**
 * 用户模块：/api/me、/api/me/bills、/api/me/balance
 */

import type { Env } from './types';
import { json, paginate, publicUser } from './db';
import { requireAuth } from './auth';

interface BillRowLite {
  id: string;
  type: string;
  amount: number;
  balance_after: number;
  description: string | null;
  created_at: number;
}

/** GET /api/me */
export async function me(env: Env, req: Request): Promise<Response> {
  const { user } = await requireAuth(env, req);
  return json(publicUser(user));
}

/** GET /api/me/bills?page=1&pageSize=20 按时间倒序 */
export async function myBills(env: Env, req: Request, url: URL): Promise<Response> {
  const { user } = await requireAuth(env, req);
  const { page, pageSize, offset } = paginate(url, 20);

  const totalRow = await env.DB.prepare('SELECT COUNT(*) AS c FROM bills WHERE user_id = ?')
    .bind(user.id)
    .first<{ c: number }>();
  const total = totalRow?.c ?? 0;

  const { results } = await env.DB.prepare(
    `SELECT id, type, amount, balance_after, description, created_at
     FROM bills WHERE user_id = ?
     ORDER BY created_at DESC, id DESC
     LIMIT ? OFFSET ?`,
  )
    .bind(user.id, pageSize, offset)
    .all<BillRowLite>();

  const list = results.map((r) => ({
    id: r.id,
    type: r.type,
    amount: r.amount,
    balanceAfter: r.balance_after,
    description: r.description,
    createdAt: r.created_at,
  }));

  return json({ list, page, pageSize, total });
}

/** GET /api/me/balance 手动刷新余额用 */
export async function myBalance(env: Env, req: Request): Promise<Response> {
  const { user } = await requireAuth(env, req);
  return json({ balance: user.balance });
}
