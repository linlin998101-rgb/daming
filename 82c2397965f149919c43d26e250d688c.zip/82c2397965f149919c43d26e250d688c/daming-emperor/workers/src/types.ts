/**
 * 共享类型与错误定义
 */

/** 环境变量 / 绑定 */
export interface Env {
  DB: D1Database;
  /** 可选：token 哈希加盐（wrangler secret put TOKEN_PEPPER），不设置也能运行 */
  TOKEN_PEPPER?: string;
  /** 密码哈希模式：pbkdf2（默认）| sha256iter（PBKDF2 超时时的回退方案） */
  PASSWORD_HASH_MODE?: string;
  /** 迭代次数，默认 10000 */
  PBKDF2_ITERATIONS?: string;
}

export interface User {
  id: string;
  nickname: string;
  password_hash: string;
  password_salt: string;
  role: string;
  balance: number;
  created_at: number;
  updated_at: number;
}

export interface SessionRow {
  id: string;
  user_id: string;
  token_hash: string;
  expires_at: number;
  revoked: number;
  created_at: number;
}

export interface AnnouncementRow {
  id: string;
  title: string;
  content: string;
  active: number;
  created_by: string;
  created_at: number;
}

export interface BillRow {
  id: string;
  user_id: string;
  type: string;
  amount: number;
  balance_after: number;
  description: string | null;
  created_by: string | null;
  created_at: number;
}

export interface AdminLogRow {
  id: string;
  admin_id: string;
  target_user_id: string | null;
  action: string;
  before_value: string | null;
  after_value: string | null;
  created_at: number;
}

/** 账单类型（默认规则） */
export const BILL_TYPES = {
  REGISTER: 'register',
  ADMIN_SET: 'admin_set',
  ADMIN_ADD: 'admin_add',
  ADMIN_SUBTRACT: 'admin_subtract',
} as const;

/** 统一业务错误：code 即 HTTP 状态码 */
export class ApiError extends Error {
  constructor(public readonly code: number, message: string) {
    super(message);
    this.name = 'ApiError';
  }
}
