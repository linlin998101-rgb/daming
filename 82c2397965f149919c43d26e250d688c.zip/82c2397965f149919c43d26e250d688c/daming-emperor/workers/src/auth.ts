/**
 * 认证模块：注册 / 登录 / 登出 / 鉴权中间件
 */

import type { Env, SessionRow, User } from './types';
import { ApiError, BILL_TYPES } from './types';
import { hashPassword, hashToken, randomHex } from './crypto';
import {
  json,
  readBody,
  nowSeconds,
  asString,
  nicknameLength,
  publicUser,
} from './db';

const SESSION_TTL_SECONDS = 30 * 24 * 3600; // Token 有效期 30 天
const NICKNAME_MIN = 2;
const NICKNAME_MAX = 20;

function validateNickname(raw: unknown): string {
  const s = asString(raw)?.trim() ?? '';
  const len = nicknameLength(s);
  if (len < NICKNAME_MIN || len > NICKNAME_MAX) {
    throw new ApiError(400, `昵称长度需为 ${NICKNAME_MIN}-${NICKNAME_MAX} 个字符`);
  }
  return s;
}

function validatePassword(raw: unknown): string {
  const s = asString(raw) ?? '';
  if (s.length < 8) throw new ApiError(400, '密码至少 8 位');
  if (!/[a-zA-Z]/.test(s) || !/[0-9]/.test(s)) {
    throw new ApiError(400, '密码需同时包含字母和数字');
  }
  return s;
}

/** 创建会话：返回明文 Token 给客户端，库中只存哈希 */
async function createSession(
  env: Env,
  userId: string,
): Promise<{ token: string; sessionId: string }> {
  const token = randomHex(32); // 64 位 hex
  const tokenHash = await hashToken(env, token);
  const sessionId = crypto.randomUUID();
  const now = nowSeconds();
  await env.DB.prepare(
    'INSERT INTO sessions (id, user_id, token_hash, expires_at, revoked, created_at) VALUES (?, ?, ?, ?, 0, ?)',
  )
    .bind(sessionId, userId, tokenHash, now + SESSION_TTL_SECONDS, now)
    .run();
  return { token, sessionId };
}

/** POST /api/auth/register */
export async function register(env: Env, req: Request): Promise<Response> {
  const body = await readBody(req);

  const nickname = validateNickname(body.nickname);
  const password = validatePassword(body.password);
  const confirm = asString(body.confirmPassword) ?? '';
  if (password !== confirm) throw new ApiError(400, '两次输入的密码不一致');

  // 先查重（UNIQUE 约束作为兜底，见下方 batch 检查）
  const existing = await env.DB.prepare('SELECT id FROM users WHERE nickname = ?')
    .bind(nickname)
    .first();
  if (existing) throw new ApiError(409, '该昵称已被使用');

  const salt = randomHex(16);
  const passwordHash = await hashPassword(env, password, salt);
  const userId = crypto.randomUUID();
  const now = nowSeconds();

  // 原子写入：建用户 + 初始账单（type=register, amount=0）
  const results = await env.DB.batch([
    env.DB.prepare(
      'INSERT INTO users (id, nickname, password_hash, password_salt, role, balance, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
    ).bind(userId, nickname, passwordHash, salt, 'user', 0, now, now),
    env.DB.prepare(
      'INSERT INTO bills (id, user_id, type, amount, balance_after, description, created_by, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
    ).bind(crypto.randomUUID(), userId, BILL_TYPES.REGISTER, 0, 0, '注册成功', null, now),
  ]);
  // 并发注册撞昵称时，users 插入 changes=0 -> 409
  if (results.some((r) => r.meta.changes === 0)) {
    throw new ApiError(409, '该昵称已被使用');
  }

  const { token } = await createSession(env, userId);
  return json(
    { token, user: { id: userId, nickname, role: 'user', balance: 0 } },
    201,
  );
}

/** POST /api/auth/login */
export async function login(env: Env, req: Request): Promise<Response> {
  const body = await readBody(req);
  const nickname = asString(body.nickname)?.trim() ?? '';
  const password = asString(body.password) ?? '';
  if (!nickname || !password) throw new ApiError(400, '昵称和密码不能为空');

  const row = await env.DB.prepare('SELECT * FROM users WHERE nickname = ?').bind(nickname).first();
  if (!row) throw new ApiError(401, '昵称或密码错误');
  const user = row as unknown as User;

  const candidate = await hashPassword(env, password, user.password_salt);
  if (candidate !== user.password_hash) throw new ApiError(401, '昵称或密码错误');

  const { token } = await createSession(env, user.id);
  return json({ token, user: publicUser(user) });
}

/** POST /api/auth/logout（吊销当前会话） */
export async function logout(env: Env, _req: Request, session: SessionRow): Promise<Response> {
  await env.DB.prepare('UPDATE sessions SET revoked = 1 WHERE id = ?').bind(session.id).run();
  return json({ success: true });
}

/** 鉴权：校验 Bearer Token，返回用户与会话；失败抛 401 */
export async function requireAuth(
  env: Env,
  req: Request,
): Promise<{ user: User; session: SessionRow }> {
  const header = req.headers.get('Authorization') ?? '';
  const token = header.startsWith('Bearer ') ? header.slice(7).trim() : '';
  if (!token) throw new ApiError(401, '未登录');

  const tokenHash = await hashToken(env, token);
  const row = await env.DB.prepare('SELECT * FROM sessions WHERE token_hash = ? LIMIT 1')
    .bind(tokenHash)
    .first();
  if (!row) throw new ApiError(401, 'Token 无效或已过期');
  const session = row as unknown as SessionRow;
  if (session.revoked !== 0 || session.expires_at <= nowSeconds()) {
    throw new ApiError(401, 'Token 无效或已过期');
  }

  const userRow = await env.DB.prepare('SELECT * FROM users WHERE id = ?')
    .bind(session.user_id)
    .first();
  if (!userRow) throw new ApiError(401, 'Token 无效或已过期');

  return { user: userRow as unknown as User, session };
}

/** 管理员鉴权：额外校验 role === 'admin'，否则 403 */
export async function requireAdmin(
  env: Env,
  req: Request,
): Promise<{ user: User; session: SessionRow }> {
  const auth = await requireAuth(env, req);
  if (auth.user.role !== 'admin') throw new ApiError(403, '无权限，需要管理员账号');
  return auth;
}
