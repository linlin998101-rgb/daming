/**
 * 公告模块：/api/announcements/latest（最新一条 active 公告）
 */

import type { Env } from './types';
import { json } from './db';

/** GET /api/announcements/latest 没有 active 公告时返回 null */
export async function latestAnnouncement(env: Env): Promise<Response> {
  const row = await env.DB.prepare(
    `SELECT id, title, content, created_at
     FROM announcements
     WHERE active = 1
     ORDER BY created_at DESC, id DESC
     LIMIT 1`,
  ).first<{ id: string; title: string; content: string; created_at: number }>();

  if (!row) return json(null);
  return json({
    id: row.id,
    title: row.title,
    content: row.content,
    createdAt: row.created_at,
  });
}
