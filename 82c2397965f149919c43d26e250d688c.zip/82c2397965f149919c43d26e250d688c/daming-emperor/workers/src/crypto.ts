/**
 * 密码与 Token 的加密工具（全部基于 Web Crypto API，零依赖）
 *
 * - 密码：PBKDF2-SHA256 × 10000 次 + 随机 16 字节 salt（默认）
 *   若在 Workers 免费版 CPU 时间限制内出现超时，
 *   可通过环境变量 PASSWORD_HASH_MODE=sha256iter 切换到 SHA-256 多轮迭代方案。
 * - Token：客户端持有 64 位 hex 随机串，数据库只存 SHA-256 哈希（可选 pepper）。
 */

import type { Env } from './types';

const encoder = new TextEncoder();

/** 生成 bytes 字节的随机 hex 字符串 */
export function randomHex(bytes: number): string {
  const buf = new Uint8Array(bytes);
  crypto.getRandomValues(buf);
  return Array.from(buf, (b) => b.toString(16).padStart(2, '0')).join('');
}

/** SHA-256 hex 摘要 */
export async function sha256Hex(input: string): Promise<string> {
  const digest = await crypto.subtle.digest('SHA-256', encoder.encode(input));
  return Array.from(new Uint8Array(digest), (b) => b.toString(16).padStart(2, '0')).join('');
}

/** PBKDF2-SHA256，输出 256 bit hex */
async function pbkdf2(password: string, saltHex: string, iterations: number): Promise<string> {
  const saltBytes = new Uint8Array(
    saltHex.match(/.{2}/g)?.map((h) => parseInt(h, 16)) ?? [],
  );
  const keyMaterial = await crypto.subtle.importKey(
    'raw',
    encoder.encode(password),
    'PBKDF2',
    false,
    ['deriveBits'],
  );
  const bits = await crypto.subtle.deriveBits(
    { name: 'PBKDF2', hash: 'SHA-256', salt: saltBytes, iterations },
    keyMaterial,
    256,
  );
  return Array.from(new Uint8Array(bits), (b) => b.toString(16).padStart(2, '0')).join('');
}

/** 回退方案：SHA-256 多轮迭代（不使用 PBKDF2，兼容性最好） */
async function sha256Iterated(password: string, saltHex: string, rounds: number): Promise<string> {
  let h = `${saltHex}:${password}`;
  for (let i = 0; i < rounds; i++) {
    h = await sha256Hex(h);
  }
  return h;
}

/** 计算密码哈希（模式由环境变量控制，默认 pbkdf2） */
export async function hashPassword(env: Env, password: string, saltHex: string): Promise<string> {
  const iterations = Math.max(1, parseInt(env.PBKDF2_ITERATIONS ?? '10000', 10) || 10000);
  const mode = (env.PASSWORD_HASH_MODE ?? 'pbkdf2').toLowerCase();
  if (mode === 'sha256iter') {
    return sha256Iterated(password, saltHex, iterations);
  }
  return pbkdf2(password, saltHex, iterations);
}

/** 计算 Token 的存储哈希（SHA-256，可选 pepper 增强） */
export async function hashToken(env: Env, token: string): Promise<string> {
  const pepper = env.TOKEN_PEPPER ?? '';
  return sha256Hex(pepper + token);
}
