/**
 * 《大明皇帝》Cloudflare Workers 入口
 * 路由：/api/auth/register|login|logout
 *       /api/me | /api/me/bills | /api/me/balance
 *       /api/announcements/latest
 *       /api/admin/users | /api/admin/users/:id/balance | /api/admin/announcements
 */

import type { Env } from './types';
import { ApiError } from './types';
import { json, fail, nowSeconds } from './db';
import { register, login, logout, requireAuth } from './auth';
import { me, myBills, myBalance } from './user';
import { latestAnnouncement } from './announcement';
import { adminUsers, adminSetBalance, adminAnnouncement } from './admin';

function withCors(resp: Response): Response {
  const headers = new Headers(resp.headers);
  headers.set('Access-Control-Allow-Origin', '*');
  headers.set('Access-Control-Allow-Methods', 'GET, POST, PATCH, OPTIONS');
  headers.set('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  return new Response(resp.body, {
    status: resp.status,
    statusText: resp.statusText,
    headers,
  });
}

export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    const url = new URL(request.url);
    const method = request.method;

    // CORS 预检（Web 调试用；Android 原生请求不受影响）
    if (method === 'OPTIONS') {
      return withCors(new Response(null, { status: 204 }));
    }

    try {
      const p = url.pathname;
      const segments = p.split('/').filter(Boolean);
      let resp: Response;

      if (method === 'POST' && p === '/api/auth/register') {
        resp = await register(env, request);
      } else if (method === 'POST' && p === '/api/auth/login') {
        resp = await login(env, request);
      } else if (method === 'POST' && p === '/api/auth/logout') {
        const { session } = await requireAuth(env, request);
        resp = await logout(env, request, session);
      } else if (method === 'GET' && p === '/api/me') {
        resp = await me(env, request);
      } else if (method === 'GET' && p === '/api/me/bills') {
        resp = await myBills(env, request, url);
      } else if (method === 'GET' && p === '/api/me/balance') {
        resp = await myBalance(env, request);
      } else if (method === 'GET' && p === '/api/announcements/latest') {
        resp = await latestAnnouncement(env);
      } else if (method === 'GET' && p === '/api/admin/users') {
        resp = await adminUsers(env, request, url);
      } else if (
        method === 'PATCH' &&
        segments.length === 5 &&
        segments[0] === 'api' &&
        segments[1] === 'admin' &&
        segments[2] === 'users' &&
        segments[4] === 'balance'
      ) {
        resp = await adminSetBalance(env, request, url);
      } else if (method === 'POST' && p === '/api/admin/announcements') {
        resp = await adminAnnouncement(env, request);
      } else if (method === 'GET' && p === '/api/ping') {
        // 健康检查：用于确认 Worker 在线
        resp = json({ ping: 'ok', ts: nowSeconds() });
      } else if (method === 'GET' && p === '/') {
        // 根路径友好提示，方便浏览器直接打开排查
        resp = json({ app: 'daming-emperor', status: 'ok' });
      } else {
        throw new ApiError(404, '接口不存在');
      }

      return withCors(resp);
    } catch (e) {
      if (e instanceof ApiError) {
        return withCors(fail(e.code, e.message));
      }
      console.error('[unhandled]', e);
      return withCors(fail(500, '服务器内部错误'));
    }
  },
} as ExportedHandler<Env>;
