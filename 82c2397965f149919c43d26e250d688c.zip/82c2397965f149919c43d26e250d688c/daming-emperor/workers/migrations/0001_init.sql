-- ============================================================
-- 《大明皇帝》D1 数据库初始化 migration
-- 只创建表结构与索引，不插入任何初始账号。
-- 管理员账号由部署者在 D1 控制台手动将 users.role 改为 'admin'。
-- 金额单位：分（INTEGER）；时间：Unix 秒（INTEGER）。
-- 执行方式：npx wrangler d1 execute daming-emperor-db --file=./migrations/0001_init.sql --remote
-- ============================================================

CREATE TABLE IF NOT EXISTS users (
  id            TEXT PRIMARY KEY,
  nickname      TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  password_salt TEXT NOT NULL,
  role          TEXT NOT NULL DEFAULT 'user',
  balance       INTEGER NOT NULL DEFAULT 0,
  created_at    INTEGER NOT NULL,
  updated_at    INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS sessions (
  id         TEXT PRIMARY KEY,
  user_id    TEXT NOT NULL,
  token_hash TEXT NOT NULL,
  expires_at INTEGER NOT NULL,
  revoked    INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS announcements (
  id         TEXT PRIMARY KEY,
  title      TEXT NOT NULL,
  content    TEXT NOT NULL,
  active     INTEGER NOT NULL DEFAULT 1,
  created_by TEXT NOT NULL,
  created_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS bills (
  id            TEXT PRIMARY KEY,
  user_id       TEXT NOT NULL,
  type          TEXT NOT NULL,
  amount        INTEGER NOT NULL,
  balance_after INTEGER NOT NULL,
  description   TEXT,
  created_by    TEXT,
  created_at    INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS admin_logs (
  id             TEXT PRIMARY KEY,
  admin_id       TEXT NOT NULL,
  target_user_id TEXT,
  action         TEXT NOT NULL,
  before_value   TEXT,
  after_value    TEXT,
  created_at     INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_sessions_token_hash ON sessions(token_hash);
CREATE INDEX IF NOT EXISTS idx_sessions_user_id     ON sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_announcements_active ON announcements(active, created_at);
CREATE INDEX IF NOT EXISTS idx_bills_user_created   ON bills(user_id, created_at);
CREATE INDEX IF NOT EXISTS idx_admin_logs_admin     ON admin_logs(admin_id);
