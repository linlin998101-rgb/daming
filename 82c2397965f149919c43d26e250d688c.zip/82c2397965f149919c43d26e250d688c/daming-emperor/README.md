# 《大明皇帝》—— 小型娱乐 Android APP 全栈项目

一个「Android 客户端 + Cloudflare Workers + D1 数据库」的小型娱乐应用。
功能：注册 / 登录 / 自动登录 / 退出账号 / 管理员改余额 / 管理员发全局公告 / 普通用户看公告 / 刷新余额 / 查看账单。

> 源码中**不包含任何 Cloudflare API Token、Account ID、D1 Database ID 等敏感信息**，
> 相关位置一律使用占位符，部署时按本文档自行填入。

---

## 1. 目录结构

```
daming-emperor/
├── android/                 # Android 客户端工程（Kotlin + XML）
│   └── app/src/main/
│       ├── java/com/daming/emperor/
│       │   ├── App.kt
│       │   ├── common/      # TokenStore / 错误处理 / 格式化工具
│       │   ├── data/        # Retrofit ApiService / ApiClient / Repository / DTO
│       │   └── ui/          # splash / login / register / main / bills / settings / admin
│       └── res/             # layout / values / drawable / mipmap(你的图标)
├── workers/                 # Cloudflare Workers 后端（TypeScript，零运行时依赖）
│   ├── src/                 # index.ts 路由 + auth/user/announcement/admin/crypto/db
│   ├── migrations/0001_init.sql   # D1 建表 migration（只建表，不插管理员）
│   ├── wrangler.toml        # 部署配置模板（占位符）
│   ├── package.json
│   └── tsconfig.json
├── scripts/
│   ├── make_icons.py        # 图标生成脚本（已执行，可复用）
│   ├── build-apk.sh         # 一键构建 debug 签名 release APK
│   └── harden-apk.sh        # dpt-shell 加固脚本
├── build/                   # 构建产物目录
│   ├── app-release.apk      # 加固前（debug 签名）
│   └── app-protected.apk    # 加固后（debug 签名）
└── README.md
```

---

## 2. 后端部署步骤（Cloudflare Workers + D1）

### 2.1 前置条件
- Node.js 18+、npm
- Cloudflare 账号；API Token 具备 `Workers Scripts:Edit`、`D1:Edit`、`Account Settings:Read` 权限

### 2.2 部署命令

```bash
# 1) 进入后端目录、安装依赖（npm 源不通时加 --registry=https://registry.npmmirror.com）
cd workers
npm install

# 2) 登录（二选一）
npx wrangler login
#    或使用 API Token（只在本机 shell 使用，不要写入任何文件/仓库）：
#    export CLOUDFLARE_API_TOKEN=<你的API Token>

# 3) 创建 D1 数据库，记录返回的 database_id
npx wrangler d1 create daming-emperor-db

# 4) 编辑 wrangler.toml，替换三个占位符：
#    <CLOUDFLARE_ACCOUNT_ID>  -> 你的 Cloudflare Account ID
#    <D1_DATABASE_ID>         -> 上一步返回的 database_id
#    <WORKER_NAME>            -> 例如 daming-emperor

# 5) 执行 migration（建表）
npx wrangler d1 execute daming-emperor-db --file=./migrations/0001_init.sql --remote

# 6) （可选但推荐）设置 token 哈希 pepper 密钥
npx wrangler secret put TOKEN_PEPPER

# 7) 本地预览（可选）
npx wrangler dev --remote

# 8) 部署
npx wrangler deploy
```

### 2.3 手动创建管理员（客户端无法注册出 admin）

```bash
# 先正常注册一个普通账号，然后执行：
npx wrangler d1 execute daming-emperor-db --remote \
  --command "UPDATE users SET role='admin' WHERE nickname='你的昵称';"
```

### 2.4 接口冒烟验证（curl）

```bash
BASE=https://allen998.kdns.fr

# 注册（昵称唯一，密码≥8位含字母和数字）
curl -s -X POST "$BASE/api/auth/register" -H 'Content-Type: application/json' \
  -d '{"nickname":"张三","password":"abc12345","confirmPassword":"abc12345"}'

# 登录
curl -s -X POST "$BASE/api/auth/login" -H 'Content-Type: application/json' \
  -d '{"nickname":"张三","password":"abc12345"}'

# 带 Token 查自己
curl -s "$BASE/api/me" -H "Authorization: Bearer <token>"

# 最新公告（无公告返回 null）
curl -s "$BASE/api/announcements/latest"
```

### 2.5 后端环境变量（可选）

| 变量 | 默认 | 说明 |
|---|---|---|
| `TOKEN_PEPPER` | 无 | token 哈希加盐，`wrangler secret put TOKEN_PEPPER` 设置 |
| `PASSWORD_HASH_MODE` | `pbkdf2` | 若 PBKDF2 在免费版 CPU 限制下超时，设为 `sha256iter` 切换回退方案 |
| `PBKDF2_ITERATIONS` | `10000` | 迭代次数，两种模式通用 |

---

## 3. Android 构建

### 3.1 替换 API_BASE_URL

**方式一：构建时指定（推荐，源码保持占位符）**

```bash
./gradlew :app:assembleRelease -PapiBaseUrl="https://allen998.kdns.fr/"
```

**方式二：直接改源码**（`android/app/build.gradle.kts` 中 `apiBaseUrl` 的默认值）

```kotlin
val apiBaseUrl: String =
    (project.findProperty("apiBaseUrl") as String?) ?: "https://allen998.kdns.fr/"
```

地址**必须以 `/` 结尾**。本仓库交付的 APK 已内置部署时的真实 Worker 地址，可直接安装测试。

### 3.2 一键构建（Linux/macOS，需 JDK 17 + Android SDK）

```bash
# 设置环境
export JAVA_HOME=<JDK17路径>
export ANDROID_HOME=<Android SDK路径>

# 构建 debug 签名的 release APK（产物在 build/app-release.apk）
bash scripts/build-apk.sh
```

### 3.3 Android Studio 构建

1. Android Studio 打开 `android/` 目录（推荐 Ladybug 2024.2.1 及以上，自带 JDK 17）
2. 等待 Gradle 同步（依赖走阿里云镜像，失败会自动回退官方仓库）
3. `Build > Generate Signed App Bundle / APK`，或直接 `Build > Build APK(s)`

> 说明：release 构建类型已配置为 **debug keystore 签名**，仅用于侧载测试，**不能上架应用商店**。
> debug keystore 由构建系统自动生成在 `~/.android/debug.keystore`。

---

## 4. APK 加固（dpt-shell，默认/轻量模式）

### 4.1 命令行方式

```bash
# 1) 下载 dpt-shell 发布包（含 dpt.jar 与 lib/）
#    https://github.com/luoyesiqiu/dpt-shell/releases
#    示例（版本号以实际为准）：
curl -L -o dpt.zip https://github.com/luoyesiqiu/dpt-shell/releases/download/v1.x.x/dpt-1.x.x.zip
unzip dpt.zip -d dpt

# 2) 加固（默认模式 = DEX 加密 + 基础反调试；不开启 VMP / aggressive SO 保护）
java -jar dpt/dpt.jar -a build/app-release.apk -o build/app-protected-unsigned.apk

# 3) 用 debug keystore 重新签名
$ANDROID_HOME/build-tools/34.0.0/apksigner sign \
  --ks ~/.android/debug.keystore \
  --ks-pass pass:android \
  --key-pass pass:android \
  --ks-key-alias androiddebugkey \
  --out build/app-protected.apk \
  build/app-protected-unsigned.apk
```

也可以直接运行仓库脚本（自动下载 dpt-shell 并完成签名）：

```bash
bash scripts/harden-apk.sh
```

### 4.2 加固说明与回退
- 使用 **默认/轻量模式**：仅 DEX 加密与基础反调试，性能影响最小、兼容性最好。
- 不开启 VMP、不开启 aggressive 模式的 SO 保护。
- **如果加固后出现启动崩溃或兼容性问题**，直接使用 `build/app-release.apk`（未加固版本）即可。
- 加固仅改变运行期保护，不影响功能与后端接口。

---

## 5. 功能与接口一览

| 模块 | 接口 | 说明 |
|---|---|---|
| 认证 | `POST /api/auth/register` | 昵称唯一(2-20字符)、密码≥8位含字母数字、确认密码一致，注册即登录 |
| 认证 | `POST /api/auth/login` | 返回 token + user |
| 认证 | `POST /api/auth/logout` | 吊销会话 |
| 用户 | `GET /api/me` | 当前用户信息 |
| 用户 | `GET /api/me/bills?page=&pageSize=` | 账单分页，时间倒序 |
| 用户 | `GET /api/me/balance` | 最新余额（手动刷新按钮用） |
| 公告 | `GET /api/announcements/latest` | 最新一条 active 公告，无则 null |
| 管理 | `GET /api/admin/users?page=&pageSize=` | 用户列表（服务端校验 admin） |
| 管理 | `PATCH /api/admin/users/:id/balance` | `{mode:"set"/"add", amount, description}`，D1 事务写 users+bills+admin_logs |
| 管理 | `POST /api/admin/announcements` | 发布全局公告 |

错误统一返回：`{ "error": { "code": 400|401|403|404|409|500, "message": "..." } }`

---

## 6. 测试计划

### 6.1 后端接口测试（curl / Postman 均可）
- [ ] 注册成功：返回 201 + token + user(balance=0)，同时产生一条 `register` 账单
- [ ] 昵称重复：返回 409 `该昵称已被使用`
- [ ] 昵称长度 1 / 21：返回 400
- [ ] 密码 7 位 / 纯数字 / 纯字母：返回 400
- [ ] 两次密码不一致：返回 400
- [ ] 登录成功 / 密码错误 401 / 不存在 401
- [ ] 带 Token 访问 `/api/me`；无 Token 401
- [ ] 伪造/篡改 Token：401
- [ ] `/api/me/bills` 分页、倒序正确
- [ ] `/api/announcements/latest`：有公告返回对象，无公告返回 null
- [ ] 普通用户访问 `/api/admin/*`：403
- [ ] 管理员 `PATCH balance`：set / add / add负数，说明必填(400)，目标不存在(404)，余额与账单、admin_logs 一致
- [ ] 管理员发公告：201，用户端可读到
- [ ] SQL 注入尝试（昵称传 `' OR 1=1 --` 等）：不报错、无越权

### 6.2 Android 客户端测试（真机）
- [ ] 冷启动无 Token → 登录页；有 Token → 主页
- [ ] 注册 → 自动登录进入主页；409 时昵称下方红字提示
- [ ] 登录 → 主页显示昵称与余额；刷新按钮更新余额
- [ ] 冷启动进入主页 → 公告弹窗；关闭后再次冷启动仍弹
- [ ] 账单列表倒序、金额/余额/说明显示正确，加载更多分页正常
- [ ] 设置页显示账号信息；退出账号 → 清除 Token → 登录页
- [ ] Token 过期/被吊销后任意请求 → 自动跳登录页
- [ ] 断网/后端停机 → Toast「网络连接失败，请稍后重试」
- [ ] 管理员登录 → 主页出现管理入口；普通用户不出现
- [ ] 管理页：用户列表翻页、改余额（三种模式）、发公告
- [ ] 加固后 APK 重复上述冒烟用例

---

## 7. 常见错误排查

| 现象 | 原因 | 解决 |
|---|---|---|
| `wrangler` 登录失败 | API Token 权限不足 | 在 Cloudflare 控制台确认 Token 含 Workers/D1 权限 |
| `d1 create` 后没填 database_id | 部署 500 / binding 失败 | 将输出 id 填入 wrangler.toml 的 `<D1_DATABASE_ID>` |
| migration 报表已存在 | 重复执行 | 建表语句带 `IF NOT EXISTS`，可安全重跑 |
| 注册/登录返回 500 | 密码哈希超时（免费版 CPU） | 设置 `PASSWORD_HASH_MODE=sha256iter` 后重新部署 |
| 客户端一直「网络连接失败」 | API_BASE_URL 未替换 / 不以 `/` 结尾 | 按 3.1 替换并重新构建 |
| 客户端请求报 404 | Worker 路径与接口不符 | 确认部署的是本仓库 `workers/src` 代码 |
| 客户端请求报 403 | 普通用户访问管理接口 | 在 D1 手动把 role 改成 admin |
| 加固后启动崩溃 | dpt-shell 与设备/ROM 兼容问题 | 回退使用未加固 `app-release.apk` |
| Gradle 同步失败 | 网络访问 maven 受限 | settings.gradle.kts 已配置阿里云镜像，检查网络后重试 |
| 手机无法访问后端 | 隐私模式/HTTP 明文 | 必须使用 HTTPS 地址；`usesCleartextTraffic=false` 已禁止明文 |

---

## 8. 部署检查清单

- [ ] wrangler.toml 中 `account_id`、`database_id`、`name` 已替换
- [ ] migration 已在远端执行成功
- [ ] 已手动把至少一个用户设为 `role='admin'`
- [ ] 可选：已 `wrangler secret put TOKEN_PEPPER`
- [ ] `curl` 冒烟验证：注册/登录/me/公告/管理接口全部通过
- [ ] Android 的 `API_BASE_URL` 已替换为真实 Worker 地址
- [ ] APK 已构建并完成加固（或确认使用未加固版本）
- [ ] 真机完成 6.2 冒烟用例
- [ ] 确认仓库中无任何 Token/Account ID/Database ID 明文

---

## 9. 安全注意事项（务必阅读）

1. **不要把 Cloudflare API Token 写进代码或提交到公开仓库**；只在本机 `export CLOUDFLARE_API_TOKEN` 使用。
2. 客户端只保存 `API_BASE_URL` 与登录 Token；**不含任何云凭据、数据库连接信息、管理员密钥**。
3. 管理员权限由后端根据 `users.role` 判定，客户端不保存也不可信。
4. 密码使用 PBKDF2-SHA256（10000 次）+ 随机 salt 存储；Token 只存 SHA-256 哈希并 30 天过期。
5. 所有 SQL 均参数化；migration 只建表、不插入任何初始账号。
6. debug 签名 APK 仅用于侧载测试，不能上架；上架需改用正式签名并开启 minify。
