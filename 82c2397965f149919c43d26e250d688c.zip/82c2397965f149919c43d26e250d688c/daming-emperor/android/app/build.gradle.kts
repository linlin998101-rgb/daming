plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.daming.emperor"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.daming.emperor"
        minSdk = 23
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"

        // 后端地址：构建时可用 -PapiBaseUrl=https://your-domain/ 覆盖（必须以 / 结尾）
        val apiBaseUrl: String =
            (project.findProperty("apiBaseUrl") as String?) ?: "https://allen998.kdns.fr/"
        buildConfigField("String", "API_BASE_URL", "\"${apiBaseUrl}\"")
    }

    signingConfigs {
        // release 构建使用 Android debug keystore 签名（仅用于侧载测试，不能上架）
        // debug keystore 由构建系统自动生成于 ~/.android/debug.keystore
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    buildFeatures {
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.recyclerview:recyclerview:1.3.2")

    // 网络：Retrofit + OkHttp + Gson + Coroutines
    implementation("com.squareup.retrofit2:retrofit:2.11.0")
    implementation("com.squareup.retrofit2:converter-gson:2.11.0")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("com.squareup.okhttp3:logging-interceptor:4.12.0")
    implementation("com.google.code.gson:gson:2.11.0")

    // 协程 + 生命周期
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.8.4")

    // Token 加密存储（EncryptedSharedPreferences）
    implementation("androidx.security:security-crypto:1.1.0-alpha06")
}
