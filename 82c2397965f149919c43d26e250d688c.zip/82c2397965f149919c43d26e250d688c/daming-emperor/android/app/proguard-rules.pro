# 未来开启 R8 混淆时可在此补充规则（当前 release 未开启 minify）
# Retrofit + Gson 需要保留泛型签名与数据模型
-keepattributes Signature, InnerClasses, EnclosingMethod
-keepattributes RuntimeVisibleAnnotations, RuntimeVisibleParameterAnnotations

-keep class com.daming.emperor.data.dto.** { *; }
-keepclassmembers,allowshrinking,allowobfuscation interface * {
    @retrofit2.http.* <methods>;
}
-dontwarn okhttp3.**
-dontwarn retrofit2.**
