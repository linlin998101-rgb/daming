package com.daming.emperor.data

import com.daming.emperor.data.dto.AdminUserDto
import com.daming.emperor.data.dto.AdminUserPage
import com.daming.emperor.data.dto.AnnouncementDto
import com.daming.emperor.data.dto.AnnouncementRequest
import com.daming.emperor.data.dto.BillPage
import com.daming.emperor.data.dto.LoginRequest
import com.daming.emperor.data.dto.LoginResponse
import com.daming.emperor.data.dto.RegisterRequest
import com.daming.emperor.data.dto.SetBalanceRequest
import com.daming.emperor.data.dto.UserDto

/** 页面统一的数据入口，各 Activity 通过 lifecycleScope 调用 */
object Repository {

    suspend fun register(nickname: String, password: String, confirmPassword: String): LoginResponse =
        ApiClient.service.register(RegisterRequest(nickname, password, confirmPassword))

    suspend fun login(nickname: String, password: String): LoginResponse =
        ApiClient.service.login(LoginRequest(nickname, password))

    suspend fun logout() {
        runCatching { ApiClient.service.logout() } // 登出接口失败不阻塞本地退出
    }

    suspend fun me(): UserDto = ApiClient.service.me()

    suspend fun myBills(page: Int, pageSize: Int): BillPage =
        ApiClient.service.myBills(page, pageSize)

    suspend fun myBalance(): Long = ApiClient.service.myBalance().balance

    suspend fun latestAnnouncement(): AnnouncementDto? = ApiClient.service.latestAnnouncement()

    suspend fun adminUsers(page: Int, pageSize: Int): AdminUserPage =
        ApiClient.service.adminUsers(page, pageSize)

    suspend fun setBalance(
        userId: String,
        mode: String,
        amount: Long,
        description: String,
    ): AdminUserDto = ApiClient.service
        .setBalance(userId, SetBalanceRequest(mode, amount, description))
        .user

    suspend fun postAnnouncement(title: String, content: String) {
        ApiClient.service.postAnnouncement(AnnouncementRequest(title, content))
    }
}
