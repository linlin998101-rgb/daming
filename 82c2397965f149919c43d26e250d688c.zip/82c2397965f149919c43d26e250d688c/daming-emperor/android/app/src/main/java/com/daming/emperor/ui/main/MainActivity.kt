package com.daming.emperor.ui.main

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.daming.emperor.R
import com.daming.emperor.common.formatMoney
import com.daming.emperor.common.redirectOnUnauthorized
import com.daming.emperor.common.toast
import com.daming.emperor.common.userMessage
import com.daming.emperor.data.Repository
import com.daming.emperor.ui.admin.AdminActivity
import com.daming.emperor.ui.bills.BillsActivity
import com.daming.emperor.ui.settings.SettingsActivity
import kotlinx.coroutines.launch

/**
 * 主页：
 * - 显示昵称、余额、手动刷新按钮
 * - 冷启动进入主页后请求最新公告并弹窗（不记已读，下次冷启动仍弹）
 * - 账单入口、设置入口；role=admin 时显示管理入口
 */
class MainActivity : AppCompatActivity() {

    private lateinit var tvNickname: TextView
    private lateinit var tvBalance: TextView
    private lateinit var btnAdmin: Button
    private var announcementLoaded = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvNickname = findViewById(R.id.tvNickname)
        tvBalance = findViewById(R.id.tvBalance)
        btnAdmin = findViewById(R.id.btnAdmin)

        findViewById<Button>(R.id.btnRefresh).setOnClickListener { loadBalance() }
        findViewById<Button>(R.id.btnBills).setOnClickListener {
            startActivity(Intent(this, BillsActivity::class.java))
        }
        findViewById<Button>(R.id.btnSettings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        btnAdmin.setOnClickListener {
            startActivity(Intent(this, AdminActivity::class.java))
        }

        loadMe()
        loadBalance()
        loadAnnouncementOnce()
    }

    override fun onResume() {
        super.onResume()
        // 从其它页面返回时刷新余额
        loadBalance()
    }

    private fun loadMe() {
        lifecycleScope.launch {
            try {
                val user = Repository.me()
                tvNickname.text = user.nickname
                btnAdmin.visibility = if (user.role == "admin") View.VISIBLE else View.GONE
            } catch (t: Throwable) {
                redirectOnUnauthorized(t)
            }
        }
    }

    private fun loadBalance() {
        lifecycleScope.launch {
            try {
                tvBalance.text = formatMoney(Repository.myBalance())
            } catch (t: Throwable) {
                redirectOnUnauthorized(t)
                toast(t.userMessage())
            }
        }
    }

    /** 冷启动只弹一次公告 */
    private fun loadAnnouncementOnce() {
        if (announcementLoaded) return
        announcementLoaded = true
        lifecycleScope.launch {
            try {
                val announcement = Repository.latestAnnouncement()
                if (announcement != null && !isFinishing) {
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle(announcement.title)
                        .setMessage(announcement.content)
                        .setPositiveButton("知道了", null)
                        .show()
                }
            } catch (t: Throwable) {
                // 公告拉取失败不影响主页使用
            }
        }
    }
}
