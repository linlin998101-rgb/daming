package com.daming.emperor.ui.bills

import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.daming.emperor.R
import com.daming.emperor.common.redirectOnUnauthorized
import com.daming.emperor.common.toast
import com.daming.emperor.common.userMessage
import com.daming.emperor.data.Repository
import com.daming.emperor.data.dto.BillDto
import kotlinx.coroutines.launch

/** 账单页：按时间倒序分页加载 */
class BillsActivity : AppCompatActivity() {

    private val items = mutableListOf<BillDto>()
    private lateinit var adapter: BillAdapter
    private lateinit var btnLoadMore: Button

    private var nextPage = 1
    private var hasMore = true
    private var loading = false
    private val pageSize = 20

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bills)

        adapter = BillAdapter(items)
        findViewById<RecyclerView>(R.id.rvBills).apply {
            layoutManager = LinearLayoutManager(this@BillsActivity)
            adapter = this@BillsActivity.adapter
        }

        btnLoadMore = findViewById(R.id.btnLoadMore)
        btnLoadMore.setOnClickListener { loadPage(nextPage) }

        loadPage(1)
    }

    private fun loadPage(page: Int) {
        if (loading) return
        loading = true
        btnLoadMore.isEnabled = false
        lifecycleScope.launch {
            try {
                val resp = Repository.myBills(page, pageSize)
                if (page == 1) {
                    items.clear()
                    nextPage = 1
                }
                items.addAll(resp.list)
                nextPage = resp.page + 1
                hasMore = items.size < resp.total
                adapter.notifyDataSetChanged()

                btnLoadMore.text = if (hasMore) {
                    getString(R.string.label_loaded_count, items.size, resp.total)
                } else {
                    getString(R.string.label_loaded_all, resp.total)
                }
                btnLoadMore.isEnabled = hasMore
            } catch (t: Throwable) {
                redirectOnUnauthorized(t)
                toast(t.userMessage())
            } finally {
                loading = false
            }
        }
    }
}
