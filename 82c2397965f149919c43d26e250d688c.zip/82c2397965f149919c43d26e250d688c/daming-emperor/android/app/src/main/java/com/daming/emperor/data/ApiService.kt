package com.daming.emperor.data

import com.daming.emperor.data.dto.AdminUserDto
import com.daming.emperor.data.dto.AdminUserPage
import com.daming.emperor.data.dto.AnnouncementDto
import com.daming.emperor.data.dto.AnnouncementRequest
import com.daming.emperor.data.dto.BalanceDto
import com.daming.emperor.data.dto.BillPage
import com.daming.emperor.data.dto.LoginRequest
import com.daming.emperor.data.dto.LoginResponse
import com.daming.emperor.data.dto.RegisterRequest
import com.daming.emperor.data.dto.SetBalanceRequest
import com.daming.emperor.data.dto.SetBalanceResponse
import com.daming.emperor.data.dto.SimpleResponse
import com.daming.emperor.data.dto.UserDto
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.PATCH
import retrofit2.http.POST
import retrofit2.http.Path
import retrofit2.http.Query

interface ApiService {

    // ---- 认证 ----
    @POST("api/auth/register")
    suspend fun register(@Body body: RegisterRequest): LoginResponse

    @POST("api/auth/login")
    suspend fun login(@Body body: LoginRequest): LoginResponse

    @POST("api/auth/logout")
    suspend fun logout(): SimpleResponse

    // ---- 用户 ----
    @GET("api/me")
    suspend fun me(): UserDto

    @GET("api/me/bills")
    suspend fun myBills(
        @Query("page") page: Int,
        @Query("pageSize") pageSize: Int,
    ): BillPage

    @GET("api/me/balance")
    suspend fun myBalance(): BalanceDto

    // ---- 公告 ----
    @GET("api/announcements/latest")
    suspend fun latestAnnouncement(): AnnouncementDto?

    // ---- 管理员 ----
    @GET("api/admin/users")
    suspend fun adminUsers(
        @Query("page") page: Int,
        @Query("pageSize") pageSize: Int,
    ): AdminUserPage

    @PATCH("api/admin/users/{id}/balance")
    suspend fun setBalance(
        @Path("id") userId: String,
        @Body body: SetBalanceRequest,
    ): SetBalanceResponse

    @POST("api/admin/announcements")
    suspend fun postAnnouncement(@Body body: AnnouncementRequest): AnnouncementDto
}
