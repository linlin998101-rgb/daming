package com.daming.emperor.common

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * 登录 Token 本地存储。
 * 优先使用 EncryptedSharedPreferences（AES256-GCM 加密）；
 * 极少数设备初始化失败时降级为普通 SharedPreferences，保证可用性。
 * 客户端只保存 API_BASE_URL（BuildConfig）与本 Token，不保存任何云凭据。
 */
object TokenStore {

    private const val PREFS_NAME = "daming_emperor_prefs"
    private const val KEY_TOKEN = "session_token"

    @Volatile
    private var prefs: SharedPreferences? = null

    fun init(context: Context) {
        if (prefs != null) return
        synchronized(this) {
            if (prefs != null) return
            prefs = try {
                val masterKey = MasterKey.Builder(context)
                    .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                    .build()
                EncryptedSharedPreferences.create(
                    context,
                    PREFS_NAME,
                    masterKey,
                    EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                    EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
                )
            } catch (e: Exception) {
                // 降级：设备不支持或初始化失败时使用明文 SharedPreferences
                context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            }
        }
    }

    fun saveToken(token: String) {
        prefs?.edit()?.putString(KEY_TOKEN, token)?.apply()
    }

    fun getToken(): String? = prefs?.getString(KEY_TOKEN, null)

    fun clear() {
        prefs?.edit()?.remove(KEY_TOKEN)?.apply()
    }
}
