package com.daming.emperor.ui.splash

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity
import com.daming.emperor.common.TokenStore
import com.daming.emperor.ui.login.LoginActivity
import com.daming.emperor.ui.main.MainActivity
import com.daming.emperor.R

/** 启动页：检查本地 Token，决定去登录页还是主页（无自定义启动图，系统默认过渡） */
class SplashActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        Handler(Looper.getMainLooper()).postDelayed({
            val cls = if (TokenStore.getToken() != null) {
                MainActivity::class.java
            } else {
                LoginActivity::class.java
            }
            startActivity(Intent(this, cls))
            finish()
        }, 600)
    }
}
