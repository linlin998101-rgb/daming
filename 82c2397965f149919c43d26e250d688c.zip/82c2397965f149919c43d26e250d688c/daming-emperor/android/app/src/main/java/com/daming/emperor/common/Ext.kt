package com.daming.emperor.common

import android.content.Context
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

/** 简易 Toast */
fun Context.toast(msg: String) {
    Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}

/** 分 -> "¥x.xx"（负数为 "-¥x.xx"） */
fun formatMoney(cents: Long): String {
    val sign = if (cents < 0) "-" else ""
    val v = abs(cents)
    return "$sign¥${v / 100}.${(v % 100).toString().padStart(2, '0')}"
}

/** 变动金额显示：正数 "+¥x.xx"，负数 "-¥x.xx"，零 "¥0.00" */
fun formatDelta(cents: Long): String {
    if (cents == 0L) return "¥0.00"
    return (if (cents > 0) "+" else "-") + formatMoney(abs(cents))
}

private val TIME_FORMAT = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())

/** Unix 秒 -> "yyyy-MM-dd HH:mm" */
fun formatTime(epochSeconds: Long): String = TIME_FORMAT.format(Date(epochSeconds * 1000))
