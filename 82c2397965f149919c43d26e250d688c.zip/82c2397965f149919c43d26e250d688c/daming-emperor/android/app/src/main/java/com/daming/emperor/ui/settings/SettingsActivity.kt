package com.daming.emperor.ui.settings

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.daming.emperor.R
import com.daming.emperor.common.TokenStore
import com.daming.emperor.common.redirectOnUnauthorized
import com.daming.emperor.common.toast
import com.daming.emperor.common.userMessage
import com.daming.emperor.data.Repository
import com.daming.emperor.ui.login.LoginActivity
import kotlinx.coroutines.launch

/** 设置页：账号信息 + 退出账号（清除本地 Token 并调用后端注销接口） */
class SettingsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        val tvNickname: TextView = findViewById(R.id.tvAccountNickname)
        val tvRole: TextView = findViewById(R.id.tvAccountRole)

        lifecycleScope.launch {
            try {
                val user = Repository.me()
                tvNickname.text = user.nickname
                tvRole.text = if (user.role == "admin") {
                    getString(R.string.label_role_admin)
                } else {
                    getString(R.string.label_role_user)
                }
            } catch (t: Throwable) {
                redirectOnUnauthorized(t)
                toast(t.userMessage())
            }
        }

        findViewById<Button>(R.id.btnLogout).setOnClickListener { doLogout() }
    }

    private fun doLogout() {
        lifecycleScope.launch {
            try {
                Repository.logout() // 调用后端注销接口（失败不阻塞）
            } catch (_: Throwable) {
                // 忽略：本地退出照常执行
            } finally {
                TokenStore.clear()
                toast("已退出账号")
                startActivity(
                    Intent(this@SettingsActivity, LoginActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK),
                )
            }
        }
    }
}
