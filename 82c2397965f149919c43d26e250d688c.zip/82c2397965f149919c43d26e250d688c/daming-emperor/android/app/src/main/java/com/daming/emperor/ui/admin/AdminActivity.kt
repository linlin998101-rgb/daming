package com.daming.emperor.ui.admin

import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.daming.emperor.R
import com.daming.emperor.common.formatMoney
import com.daming.emperor.common.redirectOnUnauthorized
import com.daming.emperor.common.toast
import com.daming.emperor.common.userMessage
import com.daming.emperor.data.Repository
import com.daming.emperor.data.dto.AdminUserDto
import kotlinx.coroutines.launch

/**
 * 管理页（仅 role=admin 可见入口，后端仍会校验）：
 * - 用户列表（分页，点击用户修改余额：直接设置 / 增加 / 减少）
 * - 发布全局公告
 */
class AdminActivity : AppCompatActivity() {

    private val users = mutableListOf<AdminUserDto>()
    private lateinit var adapter: AdminUserAdapter
    private lateinit var tvPage: TextView
    private lateinit var etTitle: EditText
    private lateinit var etContent: EditText

    private var page = 1
    private var total = 0
    private val pageSize = 20
    private var loading = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin)

        adapter = AdminUserAdapter(users) { user -> showBalanceDialog(user) }
        findViewById<RecyclerView>(R.id.rvUsers).apply {
            layoutManager = LinearLayoutManager(this@AdminActivity)
            adapter = this@AdminActivity.adapter
        }

        tvPage = findViewById(R.id.tvPage)
        etTitle = findViewById(R.id.etTitle)
        etContent = findViewById(R.id.etContent)

        findViewById<Button>(R.id.btnPrev).setOnClickListener {
            if (page > 1) loadUsers(page - 1)
        }
        findViewById<Button>(R.id.btnNext).setOnClickListener {
            if (page * pageSize < total) loadUsers(page + 1)
        }
        findViewById<Button>(R.id.btnPublish).setOnClickListener { doPublish() }

        loadUsers(1)
    }

    private fun loadUsers(targetPage: Int) {
        if (loading) return
        loading = true
        lifecycleScope.launch {
            try {
                val resp = Repository.adminUsers(targetPage, pageSize)
                users.clear()
                users.addAll(resp.list)
                page = resp.page
                total = resp.total
                adapter.notifyDataSetChanged()
                tvPage.text = getString(R.string.label_page, page)
            } catch (t: Throwable) {
                redirectOnUnauthorized(t)
                toast(t.userMessage())
            } finally {
                loading = false
            }
        }
    }

    /** 修改余额对话框：直接设置 / 增加 / 减少，说明必填 */
    private fun showBalanceDialog(user: AdminUserDto) {
        val density = resources.displayMetrics.density
        fun dp(v: Int) = (v * density).toInt()

        val modes = arrayOf("直接设置", "增加余额", "减少余额")

        val spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            modes,
        ).apply { setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }

        val etAmount = EditText(this).apply {
            hint = getString(R.string.hint_amount)
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or
                android.text.InputType.TYPE_NUMBER_FLAG_SIGNED
        }
        val etDesc = EditText(this).apply {
            hint = getString(R.string.hint_description)
        }

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(4), dp(8), dp(4), 0)
            addView(spinner, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            addView(
                etAmount,
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                    .apply { topMargin = dp(12) },
            )
            addView(
                etDesc,
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                    .apply { topMargin = dp(12) },
            )
        }

        AlertDialog.Builder(this)
            .setTitle("修改「${user.nickname}」的余额（当前 ${formatMoney(user.balance)}）")
            .setView(container)
            .setPositiveButton(getString(R.string.action_confirm)) { _, _ ->
                doSetBalance(user, spinner.selectedItemPosition, etAmount.text.toString(), etDesc.text.toString())
            }
            .setNegativeButton(getString(R.string.action_cancel), null)
            .show()
    }

    private fun doSetBalance(user: AdminUserDto, modeIndex: Int, amountText: String, description: String) {
        val amount = amountText.trim().toLongOrNull()
        if (amount == null) {
            toast(getString(R.string.toast_amount_invalid))
            return
        }
        if (description.trim().isEmpty()) {
            toast(getString(R.string.toast_description_required))
            return
        }

        val (mode, value) = when (modeIndex) {
            0 -> "set" to amount
            1 -> "add" to amount
            else -> "add" to -amount // 减少余额
        }

        lifecycleScope.launch {
            try {
                val updated = Repository.setBalance(user.id, mode, value, description.trim())
                toast(getString(R.string.toast_balance_updated, formatMoney(updated.balance)))
                loadUsers(page)
            } catch (t: Throwable) {
                redirectOnUnauthorized(t)
                toast(t.userMessage())
            }
        }
    }

    private fun doPublish() {
        val title = etTitle.text.toString().trim()
        val content = etContent.text.toString().trim()
        if (title.isEmpty() || content.isEmpty()) {
            toast(getString(R.string.toast_announcement_required))
            return
        }
        lifecycleScope.launch {
            try {
                Repository.postAnnouncement(title, content)
                toast(getString(R.string.toast_announcement_published))
                etTitle.text.clear()
                etContent.text.clear()
            } catch (t: Throwable) {
                redirectOnUnauthorized(t)
                toast(t.userMessage())
            }
        }
    }
}
