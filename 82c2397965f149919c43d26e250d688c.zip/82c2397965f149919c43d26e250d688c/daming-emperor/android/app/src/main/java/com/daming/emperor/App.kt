package com.daming.emperor

import android.app.Application
import com.daming.emperor.common.TokenStore

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        TokenStore.init(this)
    }
}
