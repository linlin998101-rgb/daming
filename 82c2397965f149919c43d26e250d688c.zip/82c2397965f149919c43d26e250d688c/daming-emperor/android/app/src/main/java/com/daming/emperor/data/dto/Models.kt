package com.daming.emperor.data.dto

/** 与后端 JSON 字段一一对应（camelCase） */

data class UserDto(
    val id: String,
    val nickname: String,
    val role: String,
    val balance: Long,
)

data class LoginResponse(
    val token: String,
    val user: UserDto,
)

data class RegisterRequest(
    val nickname: String,
    val password: String,
    val confirmPassword: String,
)

data class LoginRequest(
    val nickname: String,
    val password: String,
)

data class BillDto(
    val id: String,
    val type: String,
    val amount: Long,
    val balanceAfter: Long,
    val description: String?,
    val createdAt: Long,
)

data class BillPage(
    val list: List<BillDto>,
    val page: Int,
    val pageSize: Int,
    val total: Int,
)

data class BalanceDto(
    val balance: Long,
)

data class AnnouncementDto(
    val id: String,
    val title: String,
    val content: String,
    val createdAt: Long,
)

data class AdminUserDto(
    val id: String,
    val nickname: String,
    val role: String,
    val balance: Long,
    val createdAt: Long,
)

data class AdminUserPage(
    val list: List<AdminUserDto>,
    val page: Int,
    val pageSize: Int,
    val total: Int,
)

data class SetBalanceRequest(
    val mode: String, // "set" | "add"
    val amount: Long,
    val description: String,
)

data class SetBalanceResponse(
    val user: AdminUserDto,
)

data class AnnouncementRequest(
    val title: String,
    val content: String,
)

data class SimpleResponse(
    val success: Boolean,
)

/** 统一错误结构 { "error": { "code": ..., "message": ... } } */
data class ApiErrorBody(
    val error: ApiErrorDetail?,
)

data class ApiErrorDetail(
    val code: Int?,
    val message: String?,
)
