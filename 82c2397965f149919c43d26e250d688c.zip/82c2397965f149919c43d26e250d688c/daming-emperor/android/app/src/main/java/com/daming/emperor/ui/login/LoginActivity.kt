package com.daming.emperor.ui.login

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.daming.emperor.R
import com.daming.emperor.common.TokenStore
import com.daming.emperor.common.redirectOnUnauthorized
import com.daming.emperor.common.toast
import com.daming.emperor.common.userMessage
import com.daming.emperor.data.Repository
import com.daming.emperor.ui.main.MainActivity
import com.daming.emperor.ui.register.RegisterActivity
import kotlinx.coroutines.launch

class LoginActivity : AppCompatActivity() {

    private lateinit var etNickname: EditText
    private lateinit var etPassword: EditText
    private lateinit var btnLogin: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        etNickname = findViewById(R.id.etNickname)
        etPassword = findViewById(R.id.etPassword)
        btnLogin = findViewById(R.id.btnLogin)

        btnLogin.setOnClickListener { doLogin() }

        findViewById<TextView>(R.id.tvGoRegister).setOnClickListener {
            startActivity(Intent(this, RegisterActivity::class.java))
        }
    }

    private fun doLogin() {
        val nickname = etNickname.text.toString().trim()
        val password = etPassword.text.toString()
        if (nickname.isEmpty() || password.isEmpty()) {
            toast("请输入昵称和密码")
            return
        }

        btnLogin.isEnabled = false
        lifecycleScope.launch {
            try {
                val resp = Repository.login(nickname, password)
                TokenStore.saveToken(resp.token)
                startActivity(
                    Intent(this@LoginActivity, MainActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK),
                )
            } catch (t: Throwable) {
                redirectOnUnauthorized(t)
                toast(t.userMessage())
            } finally {
                btnLogin.isEnabled = true
            }
        }
    }
}
