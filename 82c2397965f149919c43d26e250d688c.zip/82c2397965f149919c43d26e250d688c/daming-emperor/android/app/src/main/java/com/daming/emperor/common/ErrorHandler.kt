package com.daming.emperor.common

import android.app.Activity
import android.content.Intent
import com.daming.emperor.data.dto.ApiErrorBody
import com.daming.emperor.ui.login.LoginActivity
import com.google.gson.Gson
import retrofit2.HttpException
import java.io.IOException

/** 把异常转成用户可读的错误消息；网络失败统一提示 */
fun Throwable.userMessage(): String = when (this) {
    is HttpException -> {
        val body = runCatching { response()?.errorBody()?.string() }.getOrNull()
        val parsed = runCatching { Gson().fromJson(body, ApiErrorBody::class.java) }.getOrNull()
        parsed?.error?.message ?: "请求失败（${code()}）"
    }
    is IOException -> "网络连接失败，请稍后重试"
    else -> "网络连接失败，请稍后重试"
}

/** 取 HTTP 状态码（非 HttpException 返回 null） */
fun Throwable.httpCode(): Int? = (this as? HttpException)?.code()

/**
 * 任何接口返回 401 时：清除本地 Token，跳转登录页。
 * 所有页面请求的 catch 中都应调用。
 */
fun Activity.redirectOnUnauthorized(t: Throwable) {
    if (t is HttpException && t.code() == 401) {
        TokenStore.clear()
        toast("登录已过期，请重新登录")
        startActivity(
            Intent(this, LoginActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK),
        )
        finish()
    }
}
