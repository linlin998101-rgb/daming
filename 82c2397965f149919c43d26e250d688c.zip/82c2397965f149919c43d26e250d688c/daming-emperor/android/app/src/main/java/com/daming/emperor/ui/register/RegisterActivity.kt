package com.daming.emperor.ui.register

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.daming.emperor.R
import com.daming.emperor.common.TokenStore
import com.daming.emperor.common.httpCode
import com.daming.emperor.common.redirectOnUnauthorized
import com.daming.emperor.common.toast
import com.daming.emperor.common.userMessage
import com.daming.emperor.data.Repository
import com.daming.emperor.ui.login.LoginActivity
import com.daming.emperor.ui.main.MainActivity
import kotlinx.coroutines.launch

class RegisterActivity : AppCompatActivity() {

    private lateinit var etNickname: EditText
    private lateinit var etPassword: EditText
    private lateinit var etConfirmPassword: EditText
    private lateinit var tvNicknameError: TextView
    private lateinit var btnRegister: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        etNickname = findViewById(R.id.etNickname)
        etPassword = findViewById(R.id.etPassword)
        etConfirmPassword = findViewById(R.id.etConfirmPassword)
        tvNicknameError = findViewById(R.id.tvNicknameError)
        btnRegister = findViewById(R.id.btnRegister)

        // 编辑昵称时把 409 红字恢复为默认提示
        etNickname.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                tvNicknameError.setTextColor(ContextCompat.getColor(this@RegisterActivity, R.color.text_secondary))
                tvNicknameError.text = getString(R.string.nickname_hint_text)
            }
        })

        btnRegister.setOnClickListener { doRegister() }

        findViewById<TextView>(R.id.tvGoLogin).setOnClickListener {
            startActivity(Intent(this, LoginActivity::class.java))
        }
    }

    private fun doRegister() {
        val nickname = etNickname.text.toString().trim()
        val password = etPassword.text.toString()
        val confirm = etConfirmPassword.text.toString()

        // 客户端预校验（与服务端规则一致）
        val nickLen = nickname.codePointCount(0, nickname.length)
        when {
            nickLen < 2 || nickLen > 20 -> {
                toast("昵称长度需为 2-20 个字符")
                return
            }
            password.length < 8 -> {
                toast("密码至少 8 位")
                return
            }
            !password.any { it.isLetter() } || !password.any { it.isDigit() } -> {
                toast("密码需同时包含字母和数字")
                return
            }
            password != confirm -> {
                toast("两次输入的密码不一致")
                return
            }
        }

        btnRegister.isEnabled = false
        lifecycleScope.launch {
            try {
                val resp = Repository.register(nickname, password, confirm)
                TokenStore.saveToken(resp.token)
                startActivity(
                    Intent(this@RegisterActivity, MainActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK),
                )
            } catch (t: Throwable) {
                redirectOnUnauthorized(t)
                if (t.httpCode() == 409) {
                    // 昵称重复：显示在昵称输入框下方
                    tvNicknameError.setTextColor(ContextCompat.getColor(this@RegisterActivity, R.color.danger))
                    tvNicknameError.text = getString(R.string.toast_nickname_used)
                } else {
                    toast(t.userMessage())
                }
            } finally {
                btnRegister.isEnabled = true
            }
        }
    }
}
