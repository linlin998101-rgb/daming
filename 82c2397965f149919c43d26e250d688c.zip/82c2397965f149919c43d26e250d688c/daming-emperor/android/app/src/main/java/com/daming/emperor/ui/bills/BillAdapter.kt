package com.daming.emperor.ui.bills

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.daming.emperor.R
import com.daming.emperor.common.formatDelta
import com.daming.emperor.common.formatMoney
import com.daming.emperor.common.formatTime
import com.daming.emperor.data.dto.BillDto

class BillAdapter(private val items: List<BillDto>) :
    RecyclerView.Adapter<BillAdapter.VH>() {

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val tvDescription: TextView = view.findViewById(R.id.tvDescription)
        val tvTime: TextView = view.findViewById(R.id.tvTime)
        val tvAmount: TextView = view.findViewById(R.id.tvAmount)
        val tvBalanceAfter: TextView = view.findViewById(R.id.tvBalanceAfter)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_bill, parent, false)
        return VH(view)
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val bill = items[position]
        holder.tvDescription.text = bill.description ?: typeLabel(bill.type)
        holder.tvTime.text = formatTime(bill.createdAt)

        holder.tvAmount.text = formatDelta(bill.amount)
        holder.tvAmount.setTextColor(
            ContextCompat.getColor(
                holder.itemView.context,
                if (bill.amount >= 0) R.color.positive else R.color.negative,
            ),
        )
        holder.tvBalanceAfter.text =
            "${holder.itemView.context.getString(R.string.label_balance_after)} ${formatMoney(bill.balanceAfter)}"
    }

    private fun typeLabel(type: String): String = when (type) {
        "register" -> "注册"
        "admin_set" -> "管理员设置余额"
        "admin_add" -> "管理员增加余额"
        "admin_subtract" -> "管理员减少余额"
        else -> type
    }
}
