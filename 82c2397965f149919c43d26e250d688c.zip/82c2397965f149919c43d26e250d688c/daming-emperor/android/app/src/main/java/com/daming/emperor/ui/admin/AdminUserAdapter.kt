package com.daming.emperor.ui.admin

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.daming.emperor.R
import com.daming.emperor.common.formatMoney
import com.daming.emperor.common.formatTime
import com.daming.emperor.data.dto.AdminUserDto

class AdminUserAdapter(
    private val items: List<AdminUserDto>,
    private val onItemClick: (AdminUserDto) -> Unit,
) : RecyclerView.Adapter<AdminUserAdapter.VH>() {

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val tvNickname: TextView = view.findViewById(R.id.tvNickname)
        val tvCreatedAt: TextView = view.findViewById(R.id.tvCreatedAt)
        val tvRole: TextView = view.findViewById(R.id.tvRole)
        val tvBalance: TextView = view.findViewById(R.id.tvBalance)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_admin_user, parent, false)
        return VH(view)
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val user = items[position]
        holder.tvNickname.text = user.nickname
        holder.tvCreatedAt.text = formatTime(user.createdAt)
        holder.tvRole.text = if (user.role == "admin") "管理员" else "用户"
        holder.tvBalance.text = formatMoney(user.balance)
        holder.itemView.setOnClickListener { onItemClick(user) }
    }
}
